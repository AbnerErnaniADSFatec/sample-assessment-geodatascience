library(testthat)
library(activelearning)

test_check("activelearning")

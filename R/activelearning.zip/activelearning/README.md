# Active Learning

Research topic on active learning using `sits` package.
